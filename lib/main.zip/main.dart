import 'package:flutter/material.dart';

class Produto {
  final String nome;
  final double preco;

  Produto({required this.nome, required this.preco});
}

class CartItem {
  final Produto produto;
  final int quantidade;

  CartItem({required this.produto, required this.quantidade});
}

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(title: 'Aula 02', home: MyHomePage());
  }
}

class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int _counter = 0;
  int _quantidade = 1;

  List<Produto> produtos = [
    Produto(nome: 'Notebook', preco: 4599.90),
    Produto(nome: 'Monitor', preco: 950.00),
    Produto(nome: 'Mouse', preco: 120.50),
    Produto(nome: 'Teclado', preco: 250.00),
    Produto(nome: 'Cadeira', preco: 899.99),
  ];

  List<CartItem> cartItens = [];

  void _incrementCounter() {
    setState(() {
      if (_counter < produtos.length - 1) {
        _counter++;
      } else {
        _counter = 0;
      }
    });
  }

  void _decrementCounter() {
    setState(() {
      if (_counter > 0) {
        _counter--;
      } else {
        _counter = produtos.length - 1;
      }
    });
  }

  void _incrementQuantidade() {
    setState(() {
      _quantidade++;
    });
  }

  void _decrementQuatidade() {
    setState(() {
      if (_quantidade > 1) {
        _quantidade--;
      }
    });
  }

  void _addToCart() {
    setState(() {
      cartItens.add(
        CartItem(produto: produtos[_counter], quantidade: _quantidade),
      );
      _quantidade = 1; // Reseta a quantidade para 1
    });
  }

  void _clearCart() {
    setState(() {
      cartItens.clear();
    });
  }

  double _calculateTotal() {
    return cartItens.fold(
      0.0,
      (sum, item) => sum + (item.produto.preco * item.quantidade),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Loja para Gamers'),
        backgroundColor: const Color.fromARGB(255, 56, 209, 158),
      ),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,

            children: <Widget>[
              Text(
                'Selecione um produto',
                style: Theme.of(context).textTheme.headlineLarge!.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 32),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Text(
                    'Produto: ${produtos[_counter].nome}',
                    style: Theme.of(context).textTheme.headlineMedium,
                  ),
                  const SizedBox(width: 10),
                  Text('|', style: Theme.of(context).textTheme.headlineLarge),
                  const SizedBox(width: 10),
                  Text(
                    'Preço(R\$): ${produtos[_counter].preco.toStringAsFixed(2)}',
                    style: Theme.of(context).textTheme.headlineMedium,
                  ),
                ],
              ),
              const SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  ElevatedButton.icon(
                    onPressed: _decrementCounter,
                    icon: Icon(Icons.arrow_back),
                    label: Text('Anterior'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color.fromARGB(255, 233, 233, 233),
                      foregroundColor: const Color.fromARGB(255, 0, 0, 0),
                      padding: EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 12,
                      ),
                      iconColor: const Color.fromARGB(255, 0, 0, 0),
                    ),
                  ),
                  const SizedBox(width: 10),
                  ElevatedButton.icon(
                    onPressed: _incrementCounter,
                    icon: Icon(Icons.arrow_forward),
                    label: Text('Próximo'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.grey.shade700,
                      foregroundColor: Colors.white,
                      padding: EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 12,
                      ),
                      iconColor: Colors.white,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 30),
              Text(
                'Quantidade: $_quantidade',
                style: Theme.of(context).textTheme.headlineSmall,
              ),
              const SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  ElevatedButton.icon(
                    onPressed: _decrementQuatidade,
                    icon: Icon(Icons.remove),
                    label: Text('Diminuir'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color.fromARGB(255, 228, 228, 228),
                      // MUDANÇA AQUI: Cor do texto e ícone
                      foregroundColor: const Color.fromARGB(255, 0, 0, 0),
                      padding: EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 12,
                      ),
                      iconColor: const Color.fromARGB(255, 0, 0, 0),
                    ),
                  ),
                  const SizedBox(width: 10),
                  ElevatedButton.icon(
                    onPressed: _incrementQuantidade,
                    icon: Icon(Icons.add),
                    label: Text('Aumentar'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.grey.shade700,
                      // MUDANÇA AQUI: Cor do texto e ícone
                      foregroundColor: Colors.white,
                      padding: EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 12,
                      ),
                      iconColor: Colors.white,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 30),
              ElevatedButton.icon(
                onPressed: _addToCart,
                icon: Icon(Icons.add_shopping_cart),
                label: Text('Adicionar ao Carrinho'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blueAccent,
                  foregroundColor: Colors.white,
                  padding: EdgeInsets.symmetric(horizontal: 24, vertical: 16),
                  textStyle: Theme.of(context).textTheme.titleMedium,
                  iconColor: Colors.white,
                ),
              ),
              const SizedBox(height: 20),
              if (cartItens.isNotEmpty) ...[
                const SizedBox(height: 10),
                Text(
                  'Seu carrinho',
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                const SizedBox(height: 10),
                Container(
                  constraints: const BoxConstraints(maxWidth: 500),
                  padding: const EdgeInsets.all(8.0),
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.grey.shade300),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Column(
                    children:
                        cartItens.map((item) {
                          return ListTile(
                            title: Text(item.produto.nome),
                            subtitle: Text(
                              '${item.quantidade} x R\$ ${item.produto.preco.toStringAsFixed(2)}',
                            ),
                            trailing: Text(
                              'Total: R\$ ${(item.produto.preco * item.quantidade).toStringAsFixed(2)}',
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                          );
                        }).toList(),
                  ),
                ),
                const SizedBox(height: 20),
                Text(
                  'Total: R\$ ${_calculateTotal().toStringAsFixed(2)}',
                  style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 10),
                TextButton.icon(
                  onPressed: _clearCart,
                  icon: Icon(Icons.delete_outline, size: 18),
                  label: Text('Limpar Carrinho'),
                  style: TextButton.styleFrom(
                    foregroundColor: Colors.white,
                    backgroundColor: const Color.fromARGB(255, 193, 193, 193),
                    iconColor: Colors.white,
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
